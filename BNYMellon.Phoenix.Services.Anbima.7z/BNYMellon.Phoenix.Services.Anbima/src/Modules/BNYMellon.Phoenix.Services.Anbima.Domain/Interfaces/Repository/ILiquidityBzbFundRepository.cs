using BNYMellon.Phoenix.Services.Anbima.Domain.Entities;

using System.Threading.Tasks;

namespace BNYMellon.Phoenix.Services.Anbima.Domain.Interfaces.Repository
{
    public interface ILiquidityBzbFundRepository
    {
        Task InsertAsync(LiquidityBzbFund liquidityBzbFund);
        Task<LiquidityBzbFund> GetByIdAsync(int id);
    }
}
