using BNYMellon.Phoenix.Foundation.Core.i8n;
using BNYMellon.Phoenix.Foundation.DataAccess.Entities.Interfaces;

using System;
using System.ComponentModel;

namespace BNYMellon.Phoenix.Services.Anbima.Domain.Entities
{
    [Description("LIQUIDITY_BZB_FUND")]
    public class LiquidityBzbFund : ISoftDelete
    {
        private const int CreateUserId = 1;

        public LiquidityBzbFund() {}
        public LiquidityBzbFund(int fundId,
                                    int assetId,
                                    int issuerId,
                                    double taxes)
        {
            FUND_ID = fundId;
            ASSET_ID = assetId;
            ISSUER_ID = issuerId;
            TAXES = taxes;

            CREATE_USERID = CreateUserId;
            CREATE_DATE = SouthAmericanTimeZone.GetSouthAmericanTimeNow();
            IMPORT_DATE = SouthAmericanTimeZone.GetSouthAmericanTimeNow();
        }

        public int ID { get; private set; }
        public int FUND_ID { get; private set; }
        public int ASSET_ID { get; private set; }
        public int ISSUER_ID { get; private set; }
        public double QUANTITY_OF_QUOTES { get; private set; }
        public double BLOCKED_QUANTITY_OF_QUOTES { get; private set; }
        public double QUOTE_VALUE { get; private set; }
        public double SUBSCRIPTION_REDEMPTION { get; private set; }
        public double CURRENT_GROSS_POSITION { get; private set; }
        public double TAXES { get; private set; }
        public double CURRENT_NET_POSITION { get; private set; }
        public double PERCENTAGE_OVER_FUND { get; private set; }
        public double PERCENTAGE_OVER_TOTAL { get; private set; }
        public string CNPJ { get; private set; }
        public string SEGMENT { get; private set; }
        public DateTime IMPORT_DATE { get; private set; }
        public int CREATE_USERID { get; private set; }
        public DateTime CREATE_DATE { get; private set; }

        public bool TaxAsSpecified()
        {
            var specified = true;

            if (TAXES <= 10)
                specified = false;

            return specified;
        }
    }
}
