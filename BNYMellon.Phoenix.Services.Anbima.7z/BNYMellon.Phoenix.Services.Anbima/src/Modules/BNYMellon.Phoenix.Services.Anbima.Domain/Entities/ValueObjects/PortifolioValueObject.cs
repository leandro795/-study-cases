using BNYMellon.Phoenix.Services.Anbima.Domain.Entities.ValueObjects.Dto;

using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace BNYMellon.Phoenix.Services.Anbima.Domain.Entities.ValueObjects
{
    public class PortifolioValueObject
    {
        [Description("id")]
        public int Id { get; set; }

        [Description("idCarteira")]
        public int IdPosition { get; set; }

        [Description("dtPosicao")]
        public DateTime DatePosition { get; set; }

        [Description("relPosicoesDAO")]
        public PositionDto Positions { get; set; }

        public bool HasPositionsShare()
        {
            return Positions.Shares.Count > 0;
        }

        public IEnumerable<ShareDto> PositionsShare()
        {
            return Positions.Shares;
        }
    }
}
