using System;
using System.ComponentModel;

namespace BNYMellon.Phoenix.Services.Anbima.Domain.Entities.ValueObjects.Dto
{
    public class ShareDto
    {
        [Description("dscCarteira")]
        public string Description { get; set; }

        [Description("dataPosicao")]
        public DateTime DatePosition { get; set; }

        [Description("ativo")]
        public string Active { get; set; }

        [Description("assetId")]
        public int AssetId { get; set; }

        [Description("issuerId")]
        public int IssuerId { get; set; }

        [Description("valorCota")]
        public double Value { get; set; }
    }
}
