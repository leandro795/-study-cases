using Bogus;
using BNYMellon.Phoenix.Services.Anbima.Domain.Entities;

using Bogus.Extensions.Brazil;

namespace BNYMellon.Phoenix.Services.Anbima.Tests.Comum
{
    internal class GenerateFaker
    {
        public static LiquidityBzbFund CreateLiquidityBzbFund(double taxes)
        {
            var securityMaster = new Faker<LiquidityBzbFund>("pt_BR")
                .RuleFor(c => c.ID, f => f.Random.Int(1, 10000))
                .RuleFor(c => c.FUND_ID,f => f.Random.Int(1, 10000))
                .RuleFor(c => c.ISSUER_ID, f => f.Random.Int(1, 10000))
                .RuleFor(c => c.ASSET_ID, f => f.Random.Int(1, 10000))
                .RuleFor(c => c.TAXES, f => taxes)
                .RuleFor(c => c.QUANTITY_OF_QUOTES, f => f.Random.Double())
                .RuleFor(c => c.QUOTE_VALUE, f => f.Random.Double())
                .RuleFor(c => c.SUBSCRIPTION_REDEMPTION, f => f.Random.Double())
                .RuleFor(c => c.CURRENT_GROSS_POSITION, f => f.Random.Double())
                .RuleFor(c => c.CURRENT_NET_POSITION, f => f.Random.Double())
                .RuleFor(c => c.PERCENTAGE_OVER_FUND, f => f.Random.Double())
                .RuleFor(c => c.PERCENTAGE_OVER_TOTAL, f => f.Random.Double())
                .RuleFor(c => c.CNPJ, f => f.Company.Cnpj())
                .RuleFor(c => c.SEGMENT, f => f.Finance.Bic())
                .RuleFor(c => c.IMPORT_DATE, f => f.Date.Past())
                .RuleFor(c => c.CREATE_USERID, f => f.Random.Int(1, 10000))
                .RuleFor(c => c.CREATE_DATE, f => f.Date.Past())
                .Generate();

            return securityMaster;
        }
    }
}
