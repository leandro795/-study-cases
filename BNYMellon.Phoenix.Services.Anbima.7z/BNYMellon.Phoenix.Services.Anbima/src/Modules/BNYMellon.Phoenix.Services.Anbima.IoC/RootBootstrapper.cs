using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using BNYMellon.Phoenix.Services.Anbima.IoC.Repositories;
using BNYMellon.Phoenix.Services.Anbima.IoC.Service;

namespace BNYMellon.Phoenix.Services.Anbima.IoC
{
    public class RootBootstrapper
    {
        public void BootstrapperRegisterServices(IServiceCollection services, IConfiguration configuration)
        {
            new RepositoryBootstrapper().ChildServiceRegister(services, configuration);
            new ServiceBootstrapper().ChildServiceRegister(services);
        }
    }
}
