using BNYMellon.Phoenix.Foundation.DataAccess.Configurations;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using BNYMellon.Phoenix.Services.Anbima.Domain.Interfaces.Repository;
using BNYMellon.Phoenix.Services.Anbima.Repositories.Gateway.Portifolio.Interfaces;
using BNYMellon.Phoenix.Services.Anbima.Repositories.Repository;

using Refit;

using System;


namespace BNYMellon.Phoenix.Services.Anbima.IoC.Repositories
{
    internal class RepositoryBootstrapper
    {
        internal void ChildServiceRegister(IServiceCollection services, IConfiguration configuration)
        {
            services.AddOracle(configuration.GetSection("ConnectionString").Value);

            services.AddScoped<ILiquidityBzbFundRepository, LiquidityBzbFundRepository>();


            services
                .AddRefitClient<IPortifolioRequest>()
                .ConfigureHttpClient(c => c.BaseAddress = new Uri(configuration.GetSection("PortifolioApi").Value));
        }
    }
}
