using BNYMellon.Phoenix.Services.Anbima.Domain.Entities.ValueObjects;

using System;
using System.Threading.Tasks;

namespace BNYMellon.Phoenix.Services.Anbima.Repositories.Gateway.Portifolio.Interfaces
{
    public interface IPortifolioGateway
    {
        Task<PortifolioValueObject> GetPositionPortifolioConsolidatedAsync(string sacCod, DateTime dateInitial);
    }
}
