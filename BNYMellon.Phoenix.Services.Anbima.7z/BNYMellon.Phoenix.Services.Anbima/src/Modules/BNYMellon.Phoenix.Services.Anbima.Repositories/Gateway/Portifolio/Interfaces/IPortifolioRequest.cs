using BNYMellon.Phoenix.Services.Anbima.Domain.Entities.ValueObjects;
using Refit;

using System;
using System.Threading.Tasks;

namespace BNYMellon.Phoenix.Services.Anbima.Repositories.Gateway.Portifolio.Interfaces
{
    public interface IPortifolioRequest
    {
        [Get("/PosicaoCarteiraAPI/api/PosicaoCarteiraConsolidada/{sacCod}/{dateInitial}")]
        [Headers("Autorizarion:")]
        Task<PortifolioValueObject> GetPositionPortifolioConsolidatedAsync(string sacCod, [Query(Format = "yyyy-MM-dd")] DateTime dateInitial);
    }
}
