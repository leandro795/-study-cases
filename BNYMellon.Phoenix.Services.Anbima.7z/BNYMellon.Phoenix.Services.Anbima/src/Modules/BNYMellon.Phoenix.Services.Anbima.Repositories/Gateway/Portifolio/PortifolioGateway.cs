using BNYMellon.Phoenix.Services.Anbima.Domain.Entities.ValueObjects;
using BNYMellon.Phoenix.Services.Anbima.Repositories.Gateway.Portifolio.Interfaces;

using System;
using System.Threading.Tasks;

namespace BNYMellon.Phoenix.Services.Anbima.Repositories.Gateway.Portifolio
{
    public class PortifolioGateway : IPortifolioGateway
    {
        private readonly IPortifolioRequest _portifolioRequest;

        public PortifolioGateway(IPortifolioRequest portifolioRequest)
        {
            _portifolioRequest = portifolioRequest;
        }

        public async Task<PortifolioValueObject> GetPositionPortifolioConsolidatedAsync(string sacCod, DateTime dateInitial)
        {
            return await _portifolioRequest
                            .GetPositionPortifolioConsolidatedAsync(sacCod, dateInitial)
                            .ConfigureAwait(false);
        }
    }
}
