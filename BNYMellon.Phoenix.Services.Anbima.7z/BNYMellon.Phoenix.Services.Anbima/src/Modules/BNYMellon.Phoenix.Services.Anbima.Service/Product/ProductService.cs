using BNYMellon.Phoenix.Foundation.DataAccess.UoW.Interfaces;

using BNYMellon.Phoenix.Services.Anbima.Domain.Entities;
using BNYMellon.Phoenix.Services.Anbima.Domain.Interfaces.Repository;
using BNYMellon.Phoenix.Services.Anbima.Repositories.Gateway.Portifolio.Interfaces;
using BNYMellon.Phoenix.Services.Anbima.Service.Product.Interfaces;

using System;
using System.Threading.Tasks;

namespace BNYMellon.Phoenix.Services.Anbima.Service.Product
{
    public class ProductService : IProductService
    {
        private readonly ILiquidityBzbFundRepository _liquidityBzbFundRepository;
        private readonly IPortifolioGateway _portifolioGateway;
        private readonly IUnitOfWork _unitOfWork;

        public ProductService(ILiquidityBzbFundRepository liquidityBzbFundRepository,
                                IPortifolioGateway portifolioGateway,
                                IUnitOfWork unitOfWork)
        {
            _liquidityBzbFundRepository = liquidityBzbFundRepository;
            _portifolioGateway = portifolioGateway;
            _unitOfWork = unitOfWork;
        }

        public async Task ProcessAsync(int fundId, DateTime dateInit)
        {
            var fund = await _liquidityBzbFundRepository
                                .GetByIdAsync(fundId)
                                .ConfigureAwait(false);

            if (fund is null)
            {
                return;
            }

            if (!fund.TaxAsSpecified())
            {
                return;
            }

            var portifolio = await _portifolioGateway
                                    .GetPositionPortifolioConsolidatedAsync(fund.CNPJ, dateInit)
                                    .ConfigureAwait(false);

            if (portifolio.HasPositionsShare())
            {
                foreach (var item in portifolio.PositionsShare())
                {
                    var liquidity = new LiquidityBzbFund(fundId,
                                                           item.AssetId,
                                                           item.IssuerId,
                                                           item.Value);

                    using (var transaction = _unitOfWork.BeginTransaction())
                    {
                        try
                        {
                            await _liquidityBzbFundRepository
                                    .InsertAsync(liquidity)
                                    .ConfigureAwait(false);

                            transaction.Commit();
                        }
                        catch
                        {
                            transaction.Rollback();
                        }
                    }

                }
            }
        }
    }
}
