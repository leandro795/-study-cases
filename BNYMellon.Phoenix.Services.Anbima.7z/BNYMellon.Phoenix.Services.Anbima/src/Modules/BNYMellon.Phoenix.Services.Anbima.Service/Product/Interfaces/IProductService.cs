using System;
using System.Threading.Tasks;

namespace BNYMellon.Phoenix.Services.Anbima.Service.Product.Interfaces
{
    public interface IProductService
    {
        Task ProcessAsync(int fundId, DateTime dateInit);
    }
}
