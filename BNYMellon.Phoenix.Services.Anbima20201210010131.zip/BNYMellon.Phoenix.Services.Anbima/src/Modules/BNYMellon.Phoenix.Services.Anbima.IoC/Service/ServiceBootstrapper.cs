using Microsoft.Extensions.DependencyInjection;

using BNYMellon.Phoenix.Services.Anbima.Service.Product;
using BNYMellon.Phoenix.Services.Anbima.Service.Product.Interfaces;
using BNYMellon.Phoenix.Services.Anbima.Service.LFT.Interfaces;
using BNYMellon.Phoenix.Services.Anbima.Service;

namespace BNYMellon.Phoenix.Services.Anbima.IoC.Service
{
    internal class ServiceBootstrapper
    {
        internal void ChildServiceRegister(IServiceCollection services)
        {
            services.AddScoped<IProductService, ProductService>();
            services.AddScoped<IAnbimaService, AnbimaService>();
        }
    }
}
