﻿using BNYMellon.Phoenix.Services.Anbima.Service.LFT.Interfaces;
using BNYMellon.Phoenix.Services.Anbima.Domain.Entities;

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using BNYMellon.Phoenix.Services.Anbima.Domain;
using BNYMellon.Phoenix.Services.Anbima.Domain.Interfaces.Repository;
using BNYMellon.Phoenix.Foundation.DataAccess.UoW.Interfaces;

namespace BNYMellon.Phoenix.Services.Anbima.Service
{
    public class AnbimaService : IAnbimaService
    {
        private readonly IApplicationSecurityMasterAssetRepository _applicationSecurityMasterAssetRepository;
        private readonly IApplicationSecurityMasterFixedIncomeRepository _applicationSecurityMasterFixedIncomeRepository;
        private readonly IUnitOfWork _unitOfWork;
        public AnbimaService(
            IUnitOfWork unitOfWork,
            IApplicationSecurityMasterAssetRepository applicationSecurityMasterAssetRepository,
            IApplicationSecurityMasterFixedIncomeRepository applicationSecurityMasterFixedIncomeRepository)
        {
            _unitOfWork = unitOfWork;
            _applicationSecurityMasterAssetRepository = applicationSecurityMasterAssetRepository;
            _applicationSecurityMasterFixedIncomeRepository = applicationSecurityMasterFixedIncomeRepository;
        }

        public async Task ProcessAsync(string fileName, byte[] file)
        {
            fileName = fileName.Replace(".txt", "");
            var insert = new List<ApplicationSecurityMasterAsset>();

            using var stream = new MemoryStream(file);
            using var reader = new StreamReader(stream);
            string linha;
            for (int i = 0; (linha = reader.ReadLine()) != null; i++)
            {
                if (i == 0)
                    continue;

                DateTime dataVencimento = Convert.ToDateTime(linha.Split(";")[0]);
                var asm = new ApplicationSecurityMasterAsset(fileName, fileName, dataVencimento);

                if (insert.FirstOrDefault(l => l.TICKER == asm.TICKER) == null)
                    insert.Add(asm);
            }

            using var transaction = _unitOfWork.BeginTransaction();

            try
            {
                foreach (var asm in insert)
                {
                    asm.ID = await _applicationSecurityMasterAssetRepository
                      .InsertAsync(asm)
                      .ConfigureAwait(false);

                    await _applicationSecurityMasterFixedIncomeRepository.InsertAsync(new ApplicationSecurityMasterFixedIncome(
                        asm.ID,
                        asm.DUE_DATE
                    ));
                }

                transaction.Commit();
            }
            catch
            {
                transaction.Rollback();
            }

        }
    }
}
