﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace BNYMellon.Phoenix.Services.Anbima.Service.LFT.Interfaces
{
    public interface IAnbimaService
    {
        Task ProcessAsync(string fileName, byte[] file);
    }
}
