﻿using BNYMellon.Phoenix.Foundation.DataAccess.Repositories;
using BNYMellon.Phoenix.Foundation.DataAccess.UoW.Interfaces;
using BNYMellon.Phoenix.Services.Anbima.Domain;
using BNYMellon.Phoenix.Services.Anbima.Domain.Interfaces.Repository;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace BNYMellon.Phoenix.Services.Anbima.Repositories.Repository
{
    public class ApplicationSecurityMasterAssetRepository : RepositoryStandard<ApplicationSecurityMasterAsset, int>, IApplicationSecurityMasterAssetRepository
    {
        protected ApplicationSecurityMasterAssetRepository(IDbConnection connection, ITransactionBase transactionBase) : base(connection, transactionBase)
        {
        }

        public async Task<int> InsertAsync(ApplicationSecurityMasterAsset applicationSecurityMasterAsset)
        {
            var sql = GenerateInsertQuery();

            return await _connection.QuerySingleAsync<int>(sql,
                                  applicationSecurityMasterAsset,
                                  transaction: _transactionBase.GetDbTransaction())
                    .ConfigureAwait(false);
        }
    }
}
