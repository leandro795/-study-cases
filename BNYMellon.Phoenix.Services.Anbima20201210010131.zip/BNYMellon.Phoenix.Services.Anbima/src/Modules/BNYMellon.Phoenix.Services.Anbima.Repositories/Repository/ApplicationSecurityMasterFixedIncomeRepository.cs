﻿using BNYMellon.Phoenix.Foundation.DataAccess.Repositories;
using BNYMellon.Phoenix.Foundation.DataAccess.UoW.Interfaces;
using BNYMellon.Phoenix.Services.Anbima.Domain.Entities;
using BNYMellon.Phoenix.Services.Anbima.Domain.Interfaces.Repository;
using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Threading.Tasks;

namespace BNYMellon.Phoenix.Services.Anbima.Repositories.Repository
{
    public class ApplicationSecurityMasterFixedIncomeRepository : RepositoryStandard<ApplicationSecurityMasterFixedIncome, int>, IApplicationSecurityMasterFixedIncomeRepository
    {
        protected ApplicationSecurityMasterFixedIncomeRepository(IDbConnection connection, ITransactionBase transactionBase) : base(connection, transactionBase)
        {
        }

        public async Task InsertAsync(ApplicationSecurityMasterFixedIncome applicationSecurityMasterFixedIncome)
        {
            var sql = GenerateInsertQuery();

            await _connection.ExecuteAsync(sql,
                                  applicationSecurityMasterFixedIncome,
                                  transaction: _transactionBase.GetDbTransaction())
                    .ConfigureAwait(false);
        }
    }
}
