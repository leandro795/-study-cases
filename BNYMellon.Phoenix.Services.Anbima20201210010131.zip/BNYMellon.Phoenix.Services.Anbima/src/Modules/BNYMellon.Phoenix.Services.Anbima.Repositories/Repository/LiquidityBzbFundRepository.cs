using BNYMellon.Phoenix.Foundation.DataAccess.Repositories;
using BNYMellon.Phoenix.Foundation.DataAccess.UoW.Interfaces;

using Dapper;

using BNYMellon.Phoenix.Services.Anbima.Domain.Entities;
using BNYMellon.Phoenix.Services.Anbima.Domain.Interfaces.Repository;

using System.Data;
using System.Threading.Tasks;

namespace BNYMellon.Phoenix.Services.Anbima.Repositories.Repository
{
    public class LiquidityBzbFundRepository : RepositoryStandard<LiquidityBzbFund, int>, ILiquidityBzbFundRepository
    {
        public LiquidityBzbFundRepository(IDbConnection connection,
                                          ITransactionBase transactionBase)
            : base(connection, transactionBase)
        {

        }

        public async Task InsertAsync(LiquidityBzbFund liquidityBzbFund)
        {
            var sql = GenerateInsertQuery();

            await _connection
                    .ExecuteAsync(sql,
                                  liquidityBzbFund,
                                  transaction: _transactionBase.GetDbTransaction())
                    .ConfigureAwait(false);
        }

        public async Task<LiquidityBzbFund> GetByIdAsync(int id)
        {
            var sql = GenerateSelectByIdQuery();

            return await _connection
                .QuerySingleOrDefaultAsync<LiquidityBzbFund>(sql, new { Id = id })
                .ConfigureAwait(false);
        }
    }
}
