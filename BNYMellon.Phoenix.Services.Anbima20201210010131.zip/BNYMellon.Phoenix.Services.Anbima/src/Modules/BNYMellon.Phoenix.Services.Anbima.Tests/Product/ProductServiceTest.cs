using BNYMellon.Phoenix.Foundation.DataAccess.UoW.Interfaces;
using BNYMellon.Phoenix.Services.Anbima.Domain.Entities;
using BNYMellon.Phoenix.Services.Anbima.Domain.Interfaces.Repository;
using BNYMellon.Phoenix.Services.Anbima.Repositories.Gateway.Portifolio.Interfaces;
using BNYMellon.Phoenix.Services.Anbima.Service.Product;
using BNYMellon.Phoenix.Services.Anbima.Tests.Comum;
using NSubstitute;
using System;
using System.Threading.Tasks;
using Xunit;

namespace BNYMellon.Phoenix.Services.Anbima.Tests.Product
{
    public class ProductServiceTest
    {
        private const int defaultReceived = 1;

        private ProductService productServices;
        private ILiquidityBzbFundRepository subLiquidityBzbFundRepository;
        private IPortifolioGateway subPortifolioGateway;
        private IUnitOfWork subUnitOfWork;

        public ProductServiceTest()
        {
            this.subLiquidityBzbFundRepository = Substitute.For<ILiquidityBzbFundRepository>();
            this.subPortifolioGateway = Substitute.For<IPortifolioGateway>();
            this.subUnitOfWork = Substitute.For<IUnitOfWork>();


            productServices = new ProductService(
                                    this.subLiquidityBzbFundRepository,
                                    this.subPortifolioGateway,
                                    this.subUnitOfWork);
        }

        [Theory]
        [InlineData(1, "01/12/2020")]
        [InlineData(9, "02/12/2020")]
        [InlineData(10, "03/12/2020")]
        public async Task Proccess_NotFound_FundId(int fundId, string dataInitial)
        {
            // Arrange
            var fund = default(LiquidityBzbFund);

            this.subLiquidityBzbFundRepository
                    .GetByIdAsync(fundId)
                    .Returns(fund);

            var date = DateTime.Parse(dataInitial);

            // Act
            await productServices
                    .ProcessAsync(fundId, date)
                    .ConfigureAwait(false);


            // Assert
            await this.subLiquidityBzbFundRepository
                        .Received(defaultReceived)
                        .GetByIdAsync(Arg.Any<int>())
                        .ConfigureAwait(false);
        }

        [Theory]
        [InlineData(1, 1.00, "01/12/2020")]
        [InlineData(9, 2.00, "02/12/2020")]
        [InlineData(10, 5.00, "03/12/2020")]
        public async Task Proccess_Found_FundId_But_Not_Tax_Specified(int fundId, double taxes, string dataInitial)
        {
            // Arrange
            var fund = GenerateFaker.CreateLiquidityBzbFund(taxes);

            this.subLiquidityBzbFundRepository
                    .GetByIdAsync(fundId)
                    .Returns(fund);

            var date = DateTime.Parse(dataInitial);

            // Act
            await productServices
                    .ProcessAsync(fundId, date)
                    .ConfigureAwait(false);


            // Assert
            await this.subLiquidityBzbFundRepository
                        .Received(defaultReceived)
                        .GetByIdAsync(Arg.Any<int>())
                        .ConfigureAwait(false);
        }
    }
}
