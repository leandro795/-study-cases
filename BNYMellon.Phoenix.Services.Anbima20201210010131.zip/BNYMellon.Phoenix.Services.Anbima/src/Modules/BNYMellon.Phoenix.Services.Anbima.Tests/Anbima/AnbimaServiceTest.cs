﻿using BNYMellon.Phoenix.Foundation.DataAccess.UoW.Interfaces;
using BNYMellon.Phoenix.Services.Anbima.Domain.Interfaces.Repository;
using BNYMellon.Phoenix.Services.Anbima.Service;
using BNYMellon.Phoenix.Services.Anbima.Service.LFT.Interfaces;
using NSubstitute;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace BNYMellon.Phoenix.Services.Anbima.Tests.Anbima
{
    public class AnbimaServiceTest
    {
        private string _pathFiles = @"D:\\Files";
        private AnbimaService _anbimaService;
        private IApplicationSecurityMasterAssetRepository _applicationSecurityMasterAssetRepository;
        private IApplicationSecurityMasterFixedIncomeRepository _applicationSecurityMasterFixedIncomeRepository;
        private IUnitOfWork subUnitOfWork;


        public AnbimaServiceTest()
        {
            _applicationSecurityMasterAssetRepository = Substitute.For<IApplicationSecurityMasterAssetRepository>();
            _applicationSecurityMasterFixedIncomeRepository = Substitute.For<IApplicationSecurityMasterFixedIncomeRepository>();
            subUnitOfWork = Substitute.For<IUnitOfWork>();

            _anbimaService = new AnbimaService(subUnitOfWork, _applicationSecurityMasterAssetRepository, _applicationSecurityMasterFixedIncomeRepository);
        }

        [Fact]
        public async Task Proccess_Run()
        {
            if (Directory.Exists(_pathFiles))
            {
                string[] fileEntries = Directory.GetFiles(_pathFiles);

                if (fileEntries.Length > 0)
                {
                    var fileName = Path.GetFileName(fileEntries[0]);
                    var firstFile = await File.ReadAllBytesAsync(fileEntries[0]);

                    await _anbimaService
                    .ProcessAsync(fileName, firstFile)
                    .ConfigureAwait(false);
                }
            }
        }

    }
}
