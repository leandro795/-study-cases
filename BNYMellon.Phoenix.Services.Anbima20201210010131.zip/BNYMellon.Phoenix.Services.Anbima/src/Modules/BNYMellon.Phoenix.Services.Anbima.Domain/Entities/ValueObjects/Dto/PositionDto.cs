using System.Collections.Generic;
using System.ComponentModel;

namespace BNYMellon.Phoenix.Services.Anbima.Domain.Entities.ValueObjects.Dto
{
    public class PositionDto
    {
        [Description("listaAcaoDAO")]
        public List<ShareDto> Shares { get; set; }
    }
}
