﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace BNYMellon.Phoenix.Services.Anbima.Domain
{
    [Description("APPLICATION_SECURITY_MASTER_ASSET")]
    public class ApplicationSecurityMasterAsset
    {
        public ApplicationSecurityMasterAsset() { }

        public ApplicationSecurityMasterAsset(
            string assetDescription,
            string instrumentTypeId,
            DateTime dueDate,
            string issuingCountryId = "BR",
            string tradingCountryId = "BR",
            string stokeExchangeId = "B3",
            string issuerId = "TESOURO NACIONAL")
        {
            ASSET_DESCRIPTION = assetDescription;
            INSTRUMENT_TYPE_ID = instrumentTypeId;
            ISSUING_COUNTRY_ID = issuingCountryId;
            TRADING_COUNTRY_ID = tradingCountryId;
            STOCK_EXCHANGE_ID = stokeExchangeId;
            INITIAL_VALIDITY = DateTime.Now;
            ISSUER_ID = issuerId;
            DUE_DATE = dueDate;
            TICKER = $"{assetDescription}{dueDate:yyyyMMdd}";
        }

        public int ID { get; set; }
        public string ASSET_DESCRIPTION { get; private set; }
        public string INSTRUMENT_TYPE_ID { get; private set; }
        public string ISSUING_COUNTRY_ID { get; private set; }
        public string TRADING_COUNTRY_ID { get; private set; }
        public string STOCK_EXCHANGE_ID { get; private set; }
        public string TICKER { get; private set; }
        public string ISSUER_ID { get; private set; }
        public DateTime INITIAL_VALIDITY { get; private set; }

        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public DateTime DUE_DATE { get; private set; }
    }
}
