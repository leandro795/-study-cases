﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace BNYMellon.Phoenix.Services.Anbima.Domain.Entities
{
    [Description("SECURITY_MASTER_FIXED_INCOME")]
    public class ApplicationSecurityMasterFixedIncome
    {
        public ApplicationSecurityMasterFixedIncome() { }

        public ApplicationSecurityMasterFixedIncome(int assetId, DateTime settlementDate)
        {
            ASSET_ID = assetId;
            SETTLEMENT_DATE = settlementDate;
        }

        public int ASSET_ID { get; private set; }
        public DateTime SETTLEMENT_DATE { get; private set; }

    }
}
