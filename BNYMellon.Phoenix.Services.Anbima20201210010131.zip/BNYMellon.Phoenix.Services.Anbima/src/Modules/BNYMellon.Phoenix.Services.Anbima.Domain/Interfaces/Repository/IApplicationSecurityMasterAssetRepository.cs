﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BNYMellon.Phoenix.Services.Anbima.Domain.Interfaces.Repository
{
    public interface IApplicationSecurityMasterAssetRepository
    {
        Task<int> InsertAsync(ApplicationSecurityMasterAsset applicationSecurityMasterAsset);
    }
}
