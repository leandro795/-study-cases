﻿using BNYMellon.Phoenix.Services.Anbima.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BNYMellon.Phoenix.Services.Anbima.Domain.Interfaces.Repository
{
    public interface IApplicationSecurityMasterFixedIncomeRepository
    {
        Task InsertAsync(ApplicationSecurityMasterFixedIncome applicationSecurityMasterFixedIncome);
    }
}
