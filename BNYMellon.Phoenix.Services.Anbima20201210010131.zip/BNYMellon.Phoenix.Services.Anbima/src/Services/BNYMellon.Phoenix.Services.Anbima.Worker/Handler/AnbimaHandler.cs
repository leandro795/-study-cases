﻿using BNYMellon.Phoenix.Foundation.Core.i8n;
using BNYMellon.Phoenix.Services.Anbima.Service.LFT.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace BNYMellon.Phoenix.Services.Anbima.Worker.Handler
{
    public class AnbimaHandler : IHostedService
    {
        private readonly IAnbimaService _anbimaService;
        private readonly IConfiguration _configuration;
        private Timer _timer;

        public AnbimaHandler(
            IConfiguration configuration,
            IAnbimaService anbimaService)
        {
            _configuration = configuration;
            _anbimaService = anbimaService;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            Console.WriteLine($"Service {nameof(AnbimaHandler)} started without execution at {SouthAmericanTimeZone.GetSouthAmericanTimeNow()}");

            _timer = new Timer(async obj => await ProcessFileAsync(),
                                null,
                                TimeSpan.FromSeconds(1),
                                TimeSpan.FromSeconds(60 * 10));

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            Console.WriteLine($"Service {nameof(AnbimaHandler)} stopped at {SouthAmericanTimeZone.GetSouthAmericanTimeNow()}");

            return Task.CompletedTask;
        }

        private async Task ProcessFileAsync()
        {
            Console.WriteLine($"Service {nameof(AnbimaHandler)} triggered execution at {SouthAmericanTimeZone.GetSouthAmericanTimeNow()}");

            try
            {
                var pathFiles = _configuration.GetValue<string>("PathFiles");
                if (Directory.Exists(pathFiles))
                {
                    string[] fileEntries = Directory.GetFiles(pathFiles);

                    if(fileEntries.Length > 0)
                    {
                        var fileName = Path.GetFileName(fileEntries[0]);
                        var firstFile = await File.ReadAllBytesAsync(fileEntries[0]);

                        await _anbimaService
                        .ProcessAsync(fileName, firstFile)
                        .ConfigureAwait(false);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            Console.WriteLine($"Service {nameof(AnbimaHandler)} concluded execution at {SouthAmericanTimeZone.GetSouthAmericanTimeNow()}");
        }
    }
}
