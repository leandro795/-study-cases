using BNYMellon.Phoenix.Foundation.Core.i8n;
using Microsoft.Extensions.Hosting;

using BNYMellon.Phoenix.Services.Anbima.Service.Product.Interfaces;

using System;
using System.Threading;
using System.Threading.Tasks;

namespace BNYMellon.Phoenix.Services.Anbima.Worker.Handler
{
    public class ProductHandler : IHostedService
    {
        private Timer _timer;
        private readonly IProductService _productServices;

        public ProductHandler(IProductService productServices)
        {
            _productServices = productServices;
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            Console.WriteLine($"Service {nameof(ProductHandler)} started without execution at {SouthAmericanTimeZone.GetSouthAmericanTimeNow()}");

            _timer = new Timer(async obj => await ProcessBzbAsync(obj),
                                null,
                                TimeSpan.FromSeconds(1),
                                TimeSpan.FromSeconds(60 * 10));

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            Console.WriteLine($"Service {nameof(ProductHandler)} stopped at {SouthAmericanTimeZone.GetSouthAmericanTimeNow()}");

            return Task.CompletedTask;
        }

        private async Task ProcessBzbAsync(object state)
        {
            Console.WriteLine($"Service {nameof(ProductHandler)} triggered execution at {SouthAmericanTimeZone.GetSouthAmericanTimeNow()}");

            try
            {
                await _productServices
                        .ProcessAsync(10, DateTime.Now)
                        .ConfigureAwait(false);
            }
            catch (Exception)
            {
                throw;
            }

            Console.WriteLine($"Service {nameof(ProductHandler)} concluded execution at {SouthAmericanTimeZone.GetSouthAmericanTimeNow()}");
        }
    }
}
